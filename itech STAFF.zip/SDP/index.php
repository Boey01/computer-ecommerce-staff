<?php
	header("location:StaffMain.php");
?>